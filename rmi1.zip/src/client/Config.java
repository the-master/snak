package client;

import java.io.File;

public class Config {

	public static final int PORT = 1099;
	public static final String RMIname = "rental";

	public static String simpleTrips = "src/res/simpleTrips";
	public static String hertz = "src/res/hertz.csv";
	public static void main(String[] args) {
	}

}
